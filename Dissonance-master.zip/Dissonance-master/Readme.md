## Dissonance - Unity Voice Chat Asset

Dissonance is a drop in voice chat asset for multiplayer games built in unity. This repository does *not* contain the source code for Dissonance, it is used to host documentation and issue tracking.

 - [Homepage](https://placeholder-software.co.uk/dissonance)
 - [Unity Store](https://assetstore.unity.com/packages/slug/70078?aid=1100lJDF)
 - [Documentation](https://placeholder-software.co.uk/dissonance/docs/)
 - [Issue Tracker](https://github.com/Placeholder-Software/Dissonance/issues)
 - [Discussion Forum](https://www.reddit.com/r/dissonance_voip)
 - [Discord Server](https://discord.gg/8dKpP5W)
