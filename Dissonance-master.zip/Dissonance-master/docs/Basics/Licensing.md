Dissonance uses some open source libraries to provide audio preprocessing, postprocessing, encoding and decoding. The distribution requirements for the projects used are all very simple - you must include copies of the license files in distributions of your project.

 - [Opus License](https://opus-codec.org/license/)
 - [WebRTC License](https://webrtc.org/support/license/)
 - [RNNoise License](https://github.com/xiph/rnnoise/blob/master/COPYING)