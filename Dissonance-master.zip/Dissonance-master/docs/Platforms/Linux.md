# Linux

Running Dissonance on a Linux PC has no runtime dependencies.