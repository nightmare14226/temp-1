# Windows (UWP/Hololens)

To run Dissonance on a Windows PC within a UWP application requires [Visual Studio 2017 v141 Redist](https://www.visualstudio.com/downloads/#title-90c66ddff7b7862f11eca8ffc80762c5). It's recommended that you package this with your application and install it as part of your install process.